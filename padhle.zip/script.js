class EventManager {
    constructor() {
        this.events = this.loadEvents();
        this.currentEventId = this.loadCurrentEventId();
        this.countdownInterval = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.renderInitialUI();
        if (this.events.length > 0) {
            this.startCountdown();
        }
    }

    setupEventListeners() {
        const form = document.getElementById('eventForm');
        const addEventBtn = document.getElementById('addEventBtn');
        const manageBtn = document.getElementById('manageBtn');
        const cancelBtn = document.getElementById('cancelBtn');
        const closeEventsBtn = document.getElementById('closeEventsBtn');

        if (form) form.addEventListener('submit', (e) => this.addEvent(e));
        if (addEventBtn) addEventBtn.addEventListener('click', () => this.showFormSection());
        if (manageBtn) manageBtn.addEventListener('click', () => this.showEventsSection());
        if (cancelBtn) cancelBtn.addEventListener('click', () => this.hideFormSection());
        if (closeEventsBtn) closeEventsBtn.addEventListener('click', () => this.hideEventsSection());
    }

    addEvent(e) {
        e.preventDefault();
        const name = document.getElementById('eventName').value.trim();
        const dateTime = document.getElementById('eventDateTime').value;

        if (!name || !dateTime) return;

        const event = {
            id: Date.now(),
            name: name,
            dateTime: new Date(dateTime).getTime(),
            createdAt: Date.now()
        };

        this.events.push(event);
        this.saveEvents();

        if (!this.currentEventId) {
            this.setDefaultEvent(event.id);
        }

        this.resetForm();
        this.hideFormSection();
        this.renderInitialUI();
        this.startCountdown();
    }

    deleteEvent(id) {
        this.events = this.events.filter(e => e.id !== id);
        if (this.currentEventId === id) {
            this.currentEventId = this.events.length > 0 ? this.events[0].id : null;
            this.saveCurrentEventId();
        }
        this.saveEvents();
        this.renderInitialUI();
        if (this.events.length > 0) {
            this.startCountdown();
        }
        this.renderEventsList();
    }

    setDefaultEvent(id) {
        this.currentEventId = id;
        this.saveCurrentEventId();
        this.renderInitialUI();
        this.startCountdown();
        this.renderEventsList();
    }

    getCurrentEvent() {
        return this.events.find(e => e.id === this.currentEventId);
    }

    updateCountdown() {
        const event = this.getCurrentEvent();
        if (!event) return;

        const now = Date.now();
        const diff = event.dateTime - now;

        if (diff <= 0) {
            document.getElementById('days').textContent = '00';
            document.getElementById('hours').textContent = '00';
            document.getElementById('minutes').textContent = '00';
            document.getElementById('seconds').textContent = '00';
            return;
        }

        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);

        document.getElementById('days').textContent = days.toString().padStart(2, '0');
        document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
        document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
        document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
    }

    startCountdown() {
        if (this.countdownInterval) {
            clearInterval(this.countdownInterval);
        }
        this.updateCountdown();
        this.countdownInterval = setInterval(() => this.updateCountdown(), 1000);
    }

    renderInitialUI() {
        // Show form only if no events exist
        if (this.events.length === 0) {
            document.getElementById('formSection').classList.add('active');
            document.getElementById('countdownSection').classList.remove('active');
            document.getElementById('eventsSection').classList.remove('active');
        } else {
            // Show countdown UI if events exist
            document.getElementById('formSection').classList.remove('active');
            document.getElementById('countdownSection').classList.add('active');
            document.getElementById('eventsSection').classList.remove('active');
            this.renderCountdownUI();
        }
    }

    renderCountdownUI() {
        const event = this.getCurrentEvent();
        const eventTitle = document.getElementById('eventTitle');

        if (event) {
            eventTitle.textContent = event.name;
        } else {
            eventTitle.textContent = 'No Events';
        }
    }

    renderEventsList() {
        const container = document.getElementById('eventsContainer');
        container.innerHTML = '';

        if (this.events.length === 0) {
            container.innerHTML = '<div class="empty-state">No events added yet</div>';
            return;
        }

        this.events.forEach(event => {
            const div = document.createElement('div');
            div.className = 'event-item';
            if (event.id === this.currentEventId) {
                div.classList.add('active');
            }

            const date = new Date(event.dateTime).toLocaleDateString('en-IN', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });

            const eventId = event.id;
            div.innerHTML = `
                <div class="event-name">${event.name} • ${date}</div>
                <div class="event-actions">
                    <button class="btn-select" data-event-id="${eventId}" type="button">Set</button>
                    <button class="btn-delete" data-event-id="${eventId}" type="button">Delete</button>
                </div>
            `;
            
            // Add event listeners to buttons
            div.querySelector('.btn-select').addEventListener('click', () => {
                this.setDefaultEvent(eventId);
            });
            div.querySelector('.btn-delete').addEventListener('click', () => {
                this.deleteEvent(eventId);
            });
            
            container.appendChild(div);
        });
    }

    showFormSection() {
        document.getElementById('formSection').classList.add('active');
        document.getElementById('countdownSection').classList.remove('active');
        document.getElementById('eventsSection').classList.remove('active');
    }

    hideFormSection() {
        document.getElementById('formSection').classList.remove('active');
        if (this.events.length > 0) {
            document.getElementById('countdownSection').classList.add('active');
        }
    }

    showEventsSection() {
        document.getElementById('countdownSection').classList.remove('active');
        document.getElementById('eventsSection').classList.add('active');
        this.renderEventsList();
    }

    hideEventsSection() {
        document.getElementById('eventsSection').classList.remove('active');
        document.getElementById('countdownSection').classList.add('active');
    }

    resetForm() {
        document.getElementById('eventForm').reset();
    }

    saveEvents() {
        localStorage.setItem('events', JSON.stringify(this.events));
    }

    saveCurrentEventId() {
        localStorage.setItem('currentEventId', this.currentEventId);
    }

    loadEvents() {
        const stored = localStorage.getItem('events');
        return stored ? JSON.parse(stored) : [];
    }

    loadCurrentEventId() {
        const stored = localStorage.getItem('currentEventId');
        return stored ? parseInt(stored) : (this.events.length > 0 ? this.events[0].id : null);
    }
}

const eventManager = new EventManager();
